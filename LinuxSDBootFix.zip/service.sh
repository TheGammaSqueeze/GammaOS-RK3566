mkdir /storage/sdcard1
mount /dev/block/mmcblk1p1 /storage/sdcard1
rm /storage/sdcard1/bootFA
umount /storage/sdcard1
rm -rf /storage/sdcard1